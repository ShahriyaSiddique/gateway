$(document).ready(function () {
  $("#merchantToBusiness").click(function () {
    $("#dot2").css("background-color", "#02a69c");
    $("#title2").css("color", "#000");
    $("#marchent-info").hide();
    $("#business-info").show();
  });

  $("#businessToContact").click(function () {
    $("#dot3").css("background-color", "#02a69c");
    $("#title3").css("color", "#000");
    $("#business-info").hide();
    $("#contact-info").show();
  });

  $("#businessToMerchantBack").click(function () {
    $("#dot2").css("background-color", "#f3f3f3");
    $("#title2").css("color", "#f3f3f3");
    $("#business-info").hide();
    $("#marchent-info").show();
  });

  $("#contactToBusinessBack").click(function () {
    $("#dot3").css("background-color", "#f3f3f3");
    $("#title3").css("color", "#f3f3f3");
    $("#contact-info").hide();
    $("#business-info").show();
  });
});

// $("#submitInputs").click(function () {
//   alert($("#merchantName").val());
// });

/* bank-bkash-switch */

/* function paymentChange() {
  var select = document.getElementById("payment-method").value;
  if (select == "bkash") {
    $(".bkash").show();
    $(".bank").hide();
  }
  if (select == "bank") {
    $(".bkash").hide();
    $(".bank").show();
  }
} */
